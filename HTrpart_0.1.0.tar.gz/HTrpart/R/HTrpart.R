#' @import Hmisc
NULL
#' @import parallel
NULL
#' @import gtools
NULL
#' @import rpart
NULL

#' Wrapper R function (not to be called) to call C to identify rowmeans of combinations
#'
#' Wrapper R function to call C to identify rowmeans of possible combinations of a target size from a input number.
#' @param n Input number.
#' @param k Target size
#' @examples
#' \dontrun{
#' cc(5,2)
#' #compare with
#' apply(combinations(5,2),1,mean)
#' }
#' @export

cc=function(n,k){
.C("comb",
as.integer(n),
as.integer(k),
as.integer(rep(0,choose(n,k))),
as.integer(choose(n,k)))
}[[3]]/k


#' Wrapper R function (not to be called) to call C to determine approximate null distribution
#'
#' Wrapper R function to call C to determine approximate null distribution for a numeric response. This is employed when N is greater than or equal to 22 and utilizes 10000 equally sized bins across the sameple space.
#' @param N Number of observations.
#' @param minbuck Minimum number of observations (<N) to be included in the null distribution calculation
#' @param nc non-centrality parameter
#' @export

contC.new2=function(N,minbuck,nc=0){
n_ps=minbuck:(N-minbuck)
.C("CART_cont_2",
as.integer(n_ps),
as.integer(length(n_ps)),
as.integer(N),
as.double(nc),
as.double(rep(0,10000)),
as.integer(10000))
}[[5]]


#' Wrapper R function (not to be called) to call C to determine approximate null distribution
#'
#' Wrapper R function to call C to determine approximate null distribution for a class response. This utilizes 10000 equally sized bins across the sameple space.
#' @param n_ps Sample space to examine.
#' @param n1 Number of observations in the class of interest.
#' @param N Number of observations.
#' @param output Output storage
#' @export

peelingC<-function(n_ps,n1,N,output)
.C("peeling",as.integer(n_ps),
as.integer(length(n_ps)),
as.integer(n1),
as.integer(N),
as.double(output)
)


#' Recursive partitioning with hypothesis testing at each split
#'
#' Recursively partition a dataset with a continuous or categorical response using the maximum mean rank (continous outcome) or proportion of any observed class (categorical outcome) as the splitting mechanism to allow for hypothesis testing of each split. The partitioning will stop when there are not more statistically significant splits.
#' @param y Response variable, ties broken at random for continuous responses
#' @param x Predictor variables
#' @param sig.level Significance level (default = 0.05)
#' @param n.splits Maximum number of splits (default =500)
#' @param loop Loop through all possible support parameters (default=FALSE)
#' @param minbucket Minmum number of observations needed in each daugther node
#' @param support Percent of observations needed in each daughter node
#' @param resp.class Class of response variable (default = 'numeric')
#' @param count.type Count number of potential evaluable splits conservatively or liberally (default='liberal')
#' @return def: Terms used to create the recursive partitions
#' @return pvalue: pvalues for the significant partitions
#' @return call: Input function call parameters and data
#' @return class.id: Subgroup identifier
#' @references Dyson G, Farran B, Bolton S, Craig DB, Dombkowski A, Beebe-Dimmer JL, Powell IJ, Podgorski I, Heilbrun LK, Bock CH. The extrema of circulating miR-17 are identified as biomarkers for aggressive prostate cancer. Am J Cancer Res. 2018 Oct 1;8(10):2088-2095. PMID: 30416858; PMCID: PMC6220145.
#' @return y.org: Rank used for a continuous response
#' @examples
#' \dontrun{
#' library(HTrpart)
#' gg=HTrpart(y=kyphosis$Kyphosis,x=kyphosis[,2:4],minbucket=15,n.split=100,
#' loop=FALSE,count.type='liberal',sig.level=.05,resp.class='class')
#' }
#' @export

HTrpart<-function(y,x,sig.level=0.05,n.splits=500,loop=FALSE,
 minbucket=NULL,support=NULL,resp.class=c('numeric','class'),
 count.type=c('liberal','conservative'))
{
  count.type=match.arg(count.type)
  resp.class=match.arg(resp.class)
  if(is.null(minbucket) & is.null(support)) stop('Either minbucket or support must be specified, not neither')
  if(!is.null(minbucket) & !is.null(support)) stop('Either minbucket or support must be specified, not both')
  if(resp.class=='class' & !is.factor(y)) stop('Class option is specified but y is not a factor')

  call<-list("x"=deparse(substitute(x)),"y"=deparse(substitute(y)),"support"=support,
   "sig.level"=sig.level,'minbucket'=minbucket,'resp.class'=resp.class,'count.type'=count.type)

  # number and levels of predictor variables
  x.vars<-ncol(x)
  x.var.def<-rep(FALSE,x.vars)

  if (resp.class=='class')
  {
    y.lev=levels(y)
    y=as.numeric(y)
    y.ord=NULL
  }
  if (resp.class=='numeric')
  {
    y.ord=y=rank(y,ties='random')
  }
  # determine which predictors are catagorical
  for (i in 1:x.vars) x.var.def[i]<-is.factor(x[,i])
  # store the original x and y
  y.org<-y
  x.org<-x

  # create output storages
  iidd<-rep("0.",nrow(x.org))
  status=rep('open',nrow(x.org))
  rpart.def<-matrix("",n.splits,4)
  pvalue.out=rep(NA,n.splits)

  # cycle through the maximum number of partitions to be created
  for (jj in 1:n.splits)
  {
    lev.used=min(as.numeric(iidd[status=='open']))
    ids.to.use=which(as.numeric(iidd)==lev.used & status=='open')
    if (length(ids.to.use)==2) break
    x<-x.org[ids.to.use,,drop=FALSE]
    y<-y.org[ids.to.use]
    if (resp.class=='numeric')
    {
      y=rank(y,ties='random')
      if (!loop)
      {
        minnumber=ifelse(is.null(support),minbucket,ceiling(support*length(y)))
        result<-splitHTrpart(x.=x,y.=y,x.var.def=x.var.def,minbuck=minnumber,count.type=count.type,
         resp.class=resp.class)
      }
      if (loop)
      {
        result=loop.num.splitHTrpart(minbucket=minbucket,x.=x,y.=y,x.var.def=x.var.def,count.type=count.type,
         resp.class=resp.class)
      }
    }
    if (resp.class=='class')
    {
      minnumber=ifelse(is.null(support),minbucket,ceiling(support*length(y)))
      for (i in 1:length(y.lev))
      {
         tmp<-splitHTrpart(x.=x,y.=as.numeric(y==i),x.var.def=x.var.def,minbuck=minnumber,
         count.type=count.type,resp.class=resp.class)
        assign(paste('tmp',i,sep=''),tmp,envir=.GlobalEnv)
      }
      min.pva=eval(parse(text=paste('min(',paste(paste('tmp',1:length(y.lev),'$pvalue',sep=''),
       collapse=','),')',sep='')))
      equ.pva=eval(parse(text=paste('c(',paste(paste('tmp',1:length(y.lev),'$pvalue==min.pva',sep=''),
       collapse=','),')',sep='')))
      if (sum(equ.pva)==1) result=eval(parse(text=paste('tmp',which(equ.pva),sep='')))
      if (sum(equ.pva)>1)
      {
        max.mean=eval(parse(text=paste('max(',paste(paste('tmp',c(1:length(y.lev))[equ.pva],
         '$obs.mean',sep=''),collapse=','),')',sep='')))
        equ.mean=eval(parse(text=paste('c(',paste(paste('tmp',c(1:length(y.lev))[equ.pva],
         '$obs.mean==max.mean',sep=''),collapse=','),')',sep='')))

        if (sum(equ.mean)==1) result=eval(parse(text=paste('tmp',c(c(1:length(y.lev))[equ.pva])
         [which(equ.mean)],sep='')))
        if (sum(equ.mean)>1)
        {
          max.n=eval(parse(text=paste('max(',paste('sum(',paste('tmp',c(1:length(y.lev))[ which(equ.pva)
           [which(equ.mean)]],'$out.id==1)',sep=''),collapse=','),')',sep='')))
          equ.n=eval(parse(text=paste('c(',paste('sum(',paste('tmp',c(1:length(y.lev))[ which(equ.pva)
           [which(equ.mean)]],'$out.id==1)==max.n',sep=''),collapse=','),')',sep='')))

          if (sum(equ.n)==1) result=eval(parse(text=paste('tmp',c(c(1:length(y.lev))[ which(equ.pva)
           [which(equ.mean)]])[which(equ.n)],sep='')))
          if (sum(equ.n)>1)
          {
           ru=sample(x=c(c(1:length(y.lev))[ which(equ.pva)[which(equ.mean)]])[which(equ.n)],size=1)
           result=eval(parse(text=paste('tmp',ru,sep='')))
          }
        }
      }
      result$out.n.pot=eval(parse(text=paste(paste('tmp',1:length(y.lev),'$out.n.pot',sep=''),collapse='+')))
    }
    pvalue.out[jj]=result$pvalue
    if (result$pvalue<sig.level)
    {
      rpart.def[jj,1]=unique(iidd[ids.to.use])
      iidd[ids.to.use]=paste(iidd[ids.to.use],result$out.id,sep='')
      rpart.def[jj,2]=paste(sort(unique(iidd[ids.to.use])),collapse='_')
      rpart.def[jj,3]=result$out.name
      rpart.def[jj,4]=result$out.best.desc
    }
    if (result$pvalue>=sig.level | result$out.name=='empty') status[ids.to.use]='closed'

    if (all(status=='closed')) break
  }
  sig.node=which(rpart.def[,1]!='')
  if (length(sig.node)>0) ans=list('def'=rpart.def[sig.node,,drop=F],'pvalue'=pvalue.out[sig.node],'call'=call,'class.id'=iidd,y.ord=y.ord)
  if (length(sig.node)==0) ans=list('def'="None",'pvalue'=pvalue.out[1],'call'=call,'class.id'=iidd,y.ord=y.ord)
  class(ans)<-"HTrpart"
  return(ans)
}

#' Loop through all possible support parameters to find optimal (function not to be called)
#'
#' Loop through all possible support parameters to find optimal for the data set
#' @param minbucket Minmum number of observations needed in each daugther node
#' @param x. Predictor variables
#' @param y. Response variable, ties broken at random for continuous responses
#' @param x.var.def identify categorical predictor variable
#' @param count.type Count number of potential evauable splits conservativly or liberally (default='liberal')
#' @param resp.class Class of response variable (default = 'numeric')
#' @return result: resultant HTrpart object
#' @export

loop.num.splitHTrpart=function(minbucket=minbucket,x.,y.,x.var.def=x.var.def,count.type=count.type,
       resp.class=resp.class)
{
  sum.res=matrix(NA,100,3)
  for (i in 10:99)
  {
    minnumber=ceiling(i*length(y.)/200)
    result.tmp<-splitHTrpart(x.=x.,y.=y.,x.var.def=x.var.def,minbuck=minnumber,count.type=count.type,
      resp.class=resp.class)
    sum.res[i,1]=result.tmp$pvalue
    sum.res[i,2]=sum(result.tmp$out.id)
    sum.res[i,3]=result.tmp$obs.mean
  }
 sel=order(sum.res[,1],-sum.res[,3],-sum.res[,2],1:100)[1]
 minnumber=ceiling(sel*length(y.)/200)
 result<-splitHTrpart(x.=x.,y.=y.,x.var.def=x.var.def,minbuck=minnumber,count.type=count.type,
      resp.class=resp.class)
 class(result)='HTrpart'
 return(result)
}


#' Predict output classes to a new database for HTrpart object
#'
#' Predict output classes to a new database
#' @param object HTrpart object
#' @param newdata new data with same input predictors as the HTrpart object
#' @return outclass: output class for observation
#' @return out.pred: predicted value for each observation
#' @references Dyson G, Farran B, Bolton S, Craig DB, Dombkowski A, Beebe-Dimmer JL, Powell IJ, Podgorski I, Heilbrun LK, Bock CH. The extrema of circulating miR-17 are identified as biomarkers for aggressive prostate cancer. Am J Cancer Res. 2018 Oct 1;8(10):2088-2095. PMID: 30416858; PMCID: PMC6220145.
#' @examples
#' \dontrun{
#' library(HTrpart)
#' gg=HTrpart(y=kyphosis$Kyphosis,x=kyphosis[,2:4],minbucket=15,n.split=100,
#' loop=FALSE,count.type='liberal',sig.level=.05,resp.class='class')
#' predict(object=gg)
#' }
#' @export

predict.HTrpart=function(object,newdata=NULL)
{
  if (is.null(newdata)) newdata=eval(parse(text=object$call$x))

  out.tf=matrix(F,nrow(newdata),nrow(object$def))
  for (i in 1:ncol(out.tf))
  {
    if(length(grep('\\?',object$def[i,4]))==0) out.tf[,i]=eval(parse(text=paste('newdata$',
     object$def[,3],object$def[,4],sep='')[i]))
    if(length(grep('\\?',object$def[i,4]))==1)
    {
      selected.var=which(colnames(newdata)==object$def[i,3])
      selected.lev= paste("'",paste(strsplit(gsub('\\? ','',object$def[i,4]),'\\,')[[1]],collapse="','"),"'",sep='')
      selected.id=eval(parse(text=paste('which(newdata[,',selected.var,'] %in% c(',selected.lev,'))',sep='')))
      out.tf[selected.id,i]=T
    }
  }
  md=matrix('',nrow(object$def),3)
  md[,1]=object$def[,1]
  for (i in 1:nrow(object$def))
  {
    md[i,2:3]=strsplit(object$def[i,2],'_')[[1]]
  }
  out.class=rep('',nrow(newdata))
  for (i in 1:nrow(newdata))
  {
    begin='0.'
    col.sel=which(md[,1]==begin)
    while(length(col.sel)>0)
    {
      begin=md[col.sel,as.numeric(out.tf[i,col.sel])+2]
      col.sel=which(md[,1]==begin)
    }
    out.class[i]=begin
  }
  if (object$call$resp.class=='class')
  {
    a.=table(object$class.id,eval(parse(text=object$call$y)))
    pred.=cbind(rownames(a.),colnames(a.)[apply(a.,1,which.max)])
    colnames(pred.)=c('ID','pred')
    mergin=merge(data.frame('ID'=out.class,'Order'=1:length(out.class)),pred.)
    mergin=mergin[order(mergin$Order),]
    return(list(out.class=out.class,out.pred=mergin[,3]))
  }
  if (object$call$resp.class=='numeric')
  {
    pred.=summarize(eval(parse(text=object$call$y)),object$class.id,median)
    colnames(pred.)=c('ID','pred')
    mergin=merge(data.frame('ID'=out.class,'Order'=1:length(out.class)),pred.)
    mergin=mergin[order(mergin$Order),]
    return(list(out.class=out.class,out.pred=as.numeric(as.character(mergin[,3]))))
  }
}


#' Print an HTrpart object
#'
#' Print an HTrpart object
#' @param object HTrpart object
#' @references Dyson G, Farran B, Bolton S, Craig DB, Dombkowski A, Beebe-Dimmer JL, Powell IJ, Podgorski I, Heilbrun LK, Bock CH. The extrema of circulating miR-17 are identified as biomarkers for aggressive prostate cancer. Am J Cancer Res. 2018 Oct 1;8(10):2088-2095. PMID: 30416858; PMCID: PMC6220145.
#' @examples
#' \dontrun{
#' library(HTrpart)
#' gg=HTrpart(y=kyphosis$Kyphosis,x=kyphosis[,2:4],minbucket=15,n.split=100,
#' loop=FALSE,count.type='liberal',sig.level=.05,resp.class='class')
#' print(gg)
#' }
#' @export

print.HTrpart=function(object)
{
  if (object$def[1]=='None')
  {
  out=matrix('',1,6)
  colnames(out)=c('Mother','Daughter','Cut','Resp','N','Terminal')
  if (object$call$resp.class=='numeric') out[1,]=c('','','',sprintf(median(y),fmt='%.3f'),length(y),'')
  if (object$call$resp.class=='class') out[1,]=c('','','',paste('(',paste(
    sprintf(table(y)/length(y),fmt='%.3f'),collapse=', '),')',sep=''),length(y),'')
    out[1,6]='***'
    out[1,1]='0'
  print(noquote(out))
  }
  if (object$def[1]!='None')
  {
  y=eval(parse(text=object$call$y))
  x=eval(parse(text=object$call$x))
  n=max(nchar(object$class.id))-2

  out=matrix('',n*8-1,6)
  colnames(out)=c('Mother','Daughter','Cut','Resp','N','Terminal')
  if (object$call$resp.class=='numeric') out[1,]=c('','','',sprintf(median(y),fmt='%.3f'),length(y),'')
  if (object$call$resp.class=='class') out[1,]=c('','','',paste('(',paste(
   sprintf(table(y)/length(y),fmt='%.3f'),collapse=', '),')',sep=''),length(y),'')
  k=2
  for (i in 1:n)
  {
    if(i==1) tmp.class.m=rep('0',length(object$class.id))
    if(i>1) tmp.class.m=paste('0',substr(object$class.id,3,2+i-1),sep='')
    tmp.class.d=substr(object$class.id,2+i,2+i)
    use.lev=unique(tmp.class.m[which(tmp.class.d %in% c('0','1'))])
    for (j in 1:length(use.lev))
    {
      out[k,1]=out[k+1,1]=use.lev[j]
      out[k,2]=0
      out[k+1,2]=1
      def.id=which(gsub('\\.','',object$def)==use.lev[j])
      out[k,3]=paste('!(',object$def[def.id,3],' ',object$def[def.id,4],')',sep='')
      out[k+1,3]=paste('(',object$def[def.id,3],' ',object$def[def.id,4],')',sep='')
      ids=sort(unique(paste('0.',substr(tmp.class.m,2,max(nchar(tmp.class.m))),tmp.class.d,sep='')[tmp.class.d %in% c('0','1') & tmp.class.m==use.lev[j]]))
      n1=nchar(ids[1])
      id1=which(substr(object$class.id,1,n1) %in% ids[1])
      id2=which(substr(object$class.id,1,n1) %in% ids[2])
      if (object$call$resp.class=='numeric')
      {
        out[k,4]=sprintf(median(y[id1]),fmt='%.3f')
        out[k+1,4]=sprintf(median(y[id2]),fmt='%.3f')
      }
      if (object$call$resp.class=='class')
      {
        out[k,4]=paste('(',paste(sprintf(table(y[id1])/length(y[id1]),fmt='%.3f'),collapse=', '),')',sep='')
        out[k+1,4]=paste('(',paste(sprintf(table(y[id2])/length(y[id2]),fmt='%.3f'),collapse=', '),')',sep='')
      }
      out[k,5]=length(id1)
      out[k+1,5]=length(id2)
      k=k+2
    }
  }
  out=out[which(out[,4]!=''),]
  rownames(out)=rep('',nrow(out))
  out[which(paste('0.',substr(out[,1],2,max(nchar(out[,1]))),out[,2],sep='') %in% unique(object$class.id)),6]='***'

  md=matrix(NA,(nrow(out)-1)/2,3)
  colnames(md)=c('M','D0','D1')
  lev=paste(out[,1],out[,2],sep='')
  lev[1]='0'
  for (i in seq(2,nrow(out)-1,by=2))
  {
    md[i/2,1]=out[i,1]
    md[i/2,2]=lev[i]
    md[i/2,3]=lev[i+1]
  }
  colnames(md)=c('M','D0','D1')
  rd=matrix(NA,nrow(md),2)
  colnames(rd)=c('R0','R1')
  rd[1,]=c(1,2)
  if (nrow(rd)>1)
  {
    for (i in 2:nrow(rd))
    {
      tmp=md[i,1]
      ind=which(md[,-1]==tmp,arr.ind=T)
      rd[i,]=paste(rd[ind],c(1,2),sep='')
    }
  }
  for (i in 1:nrow(rd))
  {
    for (j in 1:2)
    {
      rd[i,j]=paste(substr(rd[i,j],1,1),'.',substr(rd[i,j],2,nchar(rd[i,j])),sep='')
    }
  }
  o=order(matrix(t(rd)))
  out=rbind(out[1,],out[-1,][o,])
  for (i in 2:nrow(out))
  {
    out[i,1]=paste(paste(rep(' ',nchar(out[i,1])),collapse=''),out[i,1],sep='')
  }
  print(noquote(out))
  }
}

#' Find the best split  (function not to be called)
#'
#' Find the best split among potential splits
#' @param x. Predictor variables
#' @param y. Response variable, ties broken at random for continuous responses
#' @param x.var.def identify categorical predictor variable
#' @param minbuck Minimum number of observations needed in each daughter node
#' @param count.type Count number of potential evaulable splits conservatively or liberally (default='liberal')
#' @param resp.class Class of response variable (default = 'numeric')
#' @export

splitHTrpart=function(x.,y.,x.var.def,minbuck,count.type,resp.class)
{
  con.out=cat.out=list(best.mean=mean(y.),best.mult=0,best.desc='empty',n.pot=0,n.pot.red=0,
   var.name='empty',best.n=0)
  if (sum(x.var.def)>1)  cat.out=categ.count(dat=x.[,which(x.var.def),drop=F],resp=y.,min.N=minbuck)
  if (sum(!x.var.def)>1) con.out=contin.count(dat=x.[,which(!x.var.def),drop=F],resp=y.,min.N=minbuck)
  tie.flag=0

  if (cat.out$best.mean>con.out$best.mean) use.me=cat.out
  if (cat.out$best.mean<con.out$best.mean) use.me=con.out
  if (cat.out$best.mean == con.out$best.mean)
  {
    tie.flag=1
    if (cat.out$best.n<con.out$best.n) use.me=cat.out
    if (cat.out$best.n>con.out$best.n) use.me=con.out
    if (cat.out$best.n==con.out$best.n)
    {
    tmp=runif(1)
    if (tmp<.5) use.me=cat.out
    if (tmp>=.5) use.me=con.out
    }
  }
  out.best.mean=use.me$best.mean
  out.best.desc=use.me$best.desc
  out.name=use.me$var.name
  if (count.type=='conservative') out.n.pot=con.out$n.pot+cat.out$n.pot
  if (count.type=='liberal') out.n.pot=con.out$n.pot.red+cat.out$n.pot.red
  if (tie.flag==0) out.best.mult=use.me$best.mult
  if (tie.flag==1) out.best.mult=con.out$best.mult+cat.out$best.mult

  if(out.n.pot>0)
  {
    out.id=rep(0,length(y.))
    if (length(grep('\\?',out.best.desc))==1)
    {
        selected.var=which(colnames(x.)==out.name)
        selected.lev= paste("'",paste(strsplit(gsub('\\? ','',out.best.desc),'\\,')[[1]],collapse="','"),"'",sep='')
        selected.id=eval(parse(text=paste('which(x.[,',selected.var,'] %in% c(',selected.lev,'))',sep='')))
        out.id[selected.id]=1
    }
    if (length(grep('\\?',out.best.desc))==0)
    {
      selected.var=which(colnames(x.)==out.name)
      selected.id=eval(parse(text=paste('which(x.[,',selected.var,']',out.best.desc,')',sep='')))
      out.id[selected.id]=1
    }

    obs.mean=use.me$best.mean

    if (resp.class=='numeric')
    {
      if (length(y.)<22)  p.res=exact.calc(length(y.),minbuck)
      if (length(y.)>=22) p.res=contC.new2(length(y.),minbuck)
      c.res=cumsum(p.res)
      max.=exp(log(out.n.pot)+log(p.res)+(out.n.pot-1)*log(c.res))
      max.[is.na(max.)]=0
      max.=max./sum(max.)
      scale.max=cumsum(max.)
      x.vals=seq((length(y.)+1)/2,length(y.)-(minbuck-1)/2,len=10001)[-1]
      out.pvalue=sum(max.[which(x.vals>=obs.mean)])
    }
    if (resp.class=='class')
    {
      p.res=peelingC(minbuck:(length(y.)-minbuck),sum(y.),length(y.),rep(0,10000))[[5]]
      c.res=cumsum(p.res)
      max.=exp(log(out.n.pot)+log(p.res)+(out.n.pot-1)*log(c.res))
      max.[is.na(max.)]=0
      max.=max./sum(max.)
      scale.max=cumsum(max.)
      out.pvalue=1-scale.max[ceiling(round(1000000000*obs.mean)/100000)-1]
    }
  }
   if (out.n.pot==0)
   {
     out.pvalue=1
     out.id=rep(0,length(y.))
     out.name='empty'
     out.best.desc='empty'
     obs.mean=use.me$best.mean
   }
  return(list(pvalue=out.pvalue,out.id=out.id,out.name=out.name,out.best.desc=out.best.desc,
   out.n.pot=out.n.pot,obs.mean=use.me$best.mean))
}

#' Find the best split among continuous predictor variables (function not to be called)
#'
#' Find the best split among potential splits
#' @param dat Continuous predictor variables
#' @param resp Response variable
#' @param min.N Minimum number of observations needed in each daughter node
#' @export

contin.count=function(dat,resp,min.N)
{
   best.desc='empty'
   best.mean=mean(resp)
   best.mult=0
   best.n=0
   n.pot=n.pot.red=0
   var.name='empty'
   for (i in 1:ncol(dat))
   {
     varb=dat[,i]
     v.tab=summarize(resp,varb,function(x) c(length(x),sum(x)))
     v.tab$M_inc=cumsum(v.tab$resp2)/cumsum(v.tab$resp)
     v.tab$N_inc=cumsum(v.tab$resp)
     v.tab$N_dec=length(resp)-v.tab$N_inc
     v.tab$M_dec=(sum(resp)-round(v.tab$M_inc*v.tab$N_inc))/v.tab$N_dec
     inc.grp=which(v.tab$M_inc>mean(resp) & v.tab$N_inc>=min.N  & v.tab$N_dec>=min.N)
     dec.grp=which(v.tab$M_dec>mean(resp) & v.tab$N_inc>=min.N  & v.tab$N_dec>=min.N)

     if (length(inc.grp)==0 & length(dec.grp)==0) max.mean=mean(resp)
     if (length(inc.grp)>0 | length(dec.grp)>0)
     {
       max.mean=max(c(v.tab$M_inc[inc.grp],c(v.tab$M_dec[dec.grp])))
       inc.pot=inc.grp[which(v.tab$M_inc[inc.grp]==max.mean)]
       dec.pot=dec.grp[which(v.tab$M_dec[dec.grp]==max.mean)]
       n.pot=n.pot+length(inc.grp)+length(dec.grp)
       n.pot.red=n.pot.red+sum(diff(inc.grp)>1)+sum(diff(dec.grp)>1)
       if (sum(diff(inc.grp)>1)+sum(diff(dec.grp)>1)==0) n.pot.red=n.pot.red+1

       if (length(c(inc.pot,dec.pot))==1 & max.mean==best.mean)
       {
         if (length(inc.pot)==1)
         {
           if (v.tab[inc.pot,]$N_inc>best.n)
           {
             var.name=colnames(dat)[i]
             best.desc=paste('<=',v.tab[inc.pot,]$varb,sep=' ')
             best.mean=max.mean
             best.mult=best.mult+1
             best.n=v.tab[inc.pot,]$N_inc
           }
         }
         if (length(dec.pot)==1)
         {
           if(v.tab[dec.pot,]$N_dec>best.n)
           {
             var.name=colnames(dat)[i]
             best.desc=paste('>',v.tab[dec.pot,]$varb,sep=' ')
             best.mean=max.mean
             best.mult=best.mult+1
             best.n=v.tab[dec.pot,]$N_dec
           }
         }
       }
       if (length(c(inc.pot,dec.pot))==1 & max.mean>best.mean)
       {
         if (length(inc.pot)==1)
         {
           var.name=colnames(dat)[i]
           best.desc=paste('<=',v.tab[inc.pot,]$varb,sep=' ')
           best.mean=max.mean
           best.mult=1
           best.n=v.tab[inc.pot,]$N_inc
         }
         if (length(dec.pot)==1)
         {
           var.name=colnames(dat)[i]
           best.desc=paste('>',v.tab[dec.pot,]$varb,sep=' ')
           best.mean=max.mean
           best.mult=1
           best.n=v.tab[dec.pot,]$N_dec
         }
       }
       if (length(c(inc.pot,dec.pot))>1 & max.mean==best.mean)
       {
         mult.best=cbind(c(rep(c(1,2),c(length(inc.pot),length(dec.pot)))),c(inc.pot,dec.pot),
          c(v.tab$N_inc[inc.pot],v.tab$N_dec[dec.pot]))
         sel.best=which.max(mult.best[,3])
         if (mult.best[sel.best,1]==1 & v.tab[mult.best[sel.best,2],]$N_inc>best.n)
         {
            var.name=colnames(dat)[i]
            best.desc=paste('<=',v.tab[mult.best[sel.best,2],]$varb,sep=' ')
            best.mean=max.mean
            best.mult=nrow(mult.best)
            best.n=v.tab[mult.best[sel.best,2],]$N_inc
          }

         if (mult.best[sel.best,1]==2 & v.tab[mult.best[sel.best,2],]$N_dec>best.n)
         {
            var.name=colnames(dat)[i]
            best.desc=paste('>',v.tab[mult.best[sel.best,2],]$varb,sep=' ')
            best.mean=max.mean
            best.mult=nrow(mult.best)
            best.n=v.tab[mult.best[sel.best,2],]$N_dec
         }
       }
       if (length(c(inc.pot,dec.pot))>1 & max.mean>best.mean)
       {
         mult.best=cbind(c(rep(c(1,2),c(length(inc.pot),length(dec.pot)))),c(inc.pot,dec.pot),
          c(v.tab$N_inc[inc.pot],v.tab$N_dec[dec.pot]))
         sel.best=which.max(mult.best[,3])
         if (mult.best[sel.best,1]==1)
         {
            var.name=colnames(dat)[i]
            best.desc=paste('<=',v.tab[mult.best[sel.best,2],]$varb,sep=' ')
            best.mean=max.mean
            best.mult=nrow(mult.best)
            best.n=v.tab[mult.best[sel.best,2],]$N_inc
         }
         if (mult.best[sel.best,1]==2)
         {
            var.name=colnames(dat)[i]
            best.desc=paste('>',v.tab[mult.best[sel.best,2],]$varb,sep=' ')
            best.mean=max.mean
            best.mult=nrow(mult.best)
            best.n=v.tab[mult.best[sel.best,2],]$N_dec
         }
       }
     }
   }
  return(list(best.mean=best.mean,best.mult=best.mult,best.desc=best.desc,n.pot=n.pot,
   best.n=best.n,var.name=var.name,n.pot.red=n.pot.red))
}


#' Find the best split among categorical predictor variables (function not to be called)
#'
#' Find the best split among potential splits
#' @param dat Categorical predictor variables
#' @param resp Response variable
#' @param min.N Minimum number of observations needed in each daughter node
#' @export

 categ.count=function(dat,resp,min.N)
 {
   best.desc='empty'
   best.mean=mean(resp)
   best.mult=0
   best.n=0
   n.pot.red=n.pot=0
   var.name='empty'
   for (i in 1:ncol(dat))
   {
     varb=dat[,i]
     v.tab=summarize(resp,varb,function(x) c(length(x),sum(x),mean(x)))
     v.tab=v.tab[rev(order(v.tab$resp3)),]
     v.tab$M_inc=cumsum(v.tab$resp2)/cumsum(v.tab$resp)
     v.tab$N_inc=cumsum(v.tab$resp)
     inc.grp=which(v.tab$M_inc>mean(resp) & v.tab$N_inc>=min.N & v.tab$N_inc<=(length(resp)-min.N))
     non.equ.means=which(rev(!duplicated(rev(v.tab[,4]))))
     inc.grp=intersect(inc.grp,non.equ.means)

     if(length(inc.grp)==0) max.mean=mean(resp)

     if (length(inc.grp)>0)
     {
       max.mean=max(c(v.tab$M_inc[inc.grp]))
       inc.pot=inc.grp[which(v.tab$M_inc[inc.grp]==max.mean)]
       n.pot=n.pot+length(inc.grp)
       n.pot.red=n.pot.red+sum(diff(inc.grp)>1)
       if (sum(diff(inc.grp)>1)==0) n.pot.red=n.pot.red+1

       if (max.mean==best.mean & v.tab[inc.pot[1],]$N_inc>best.n)
       {
         var.name=colnames(dat)[i]
         best.desc=paste('?', paste(v.tab[1:inc.pot[1],]$varb,collapse=','),sep=' ')
         best.mean=max.mean
         best.mult=1
         best.n=v.tab[inc.pot[1],]$N_inc
       }
       if (max.mean>best.mean)
       {
         var.name=colnames(dat)[i]
         best.desc=paste('?', paste(v.tab[1:inc.pot[1],]$varb,collapse=','),sep=' ')
         best.mean=max.mean
         best.mult=1
         best.n=v.tab[inc.pot[1],]$N_inc
       }
     }
   }
   return(list(best.mean=best.mean,best.mult=best.mult,best.desc=best.desc,n.pot=n.pot,best.n=best.n,
    var.name=var.name,n.pot.red=n.pot.red))
}


#' Produce a row is pascal's triangle
#'
#' Produce a row in Pascal's triangle minus the first and last 1s
#' @param N Number
#' @param log On the log scale? (default to FALSE)
#' @examples
#' \dontrun{
#' pascal(6)
#' }
#' @export

pascal=function(N,log=FALSE)
{
  if (log==TRUE)
  {
    out=rep(0,N+1)
    for (i in 2:length(out)) out[i]=log(N-i+2)+(out[i-1])-log(i-1)
  }
  if (log==FALSE)
  {
    out=rep(1,N+1)
    for (i in 2:length(out)) out[i]=(N-i+2)*out[i-1]/(i-1)
  }
  out[-c(1,length(out))]
}


#' Function (not to be called) determine exact null distribution
#'
#' Function to call C to determine exact null distribution for a numeric response. This is employed when N is less than 22 and utilizes 10000 equally sized bins across the sameple space.
#' @param N Number of observations.
#' @param minbuck Minimum number of observations (<N) to be included in the null distribution calculation
#' @examples
#' \dontrun{
#' x=exact.calc(17,10)
#' }
#' @export

exact.calc=function(N,minbuck)
{
  if ((N-minbuck)<minbuck) return(rep(NA,10000))
  n_ps=minbuck:(N-minbuck)
  n.poss.term=length(n_ps)

  pas=round(pascal(N,log=T),10)
  pote.theta=seq((N+1)/2,N-(n_ps[1]-1)/2,len=10001)[-1]
  yy=zz=rep(0,n.poss.term)
  returned=rep(0,10000)
  ids= which(pas == pas[n_ps[1]] & (1:length(pas))>=n_ps[1])
  calc=rep(0,N)
  if (length(ids)==1) calc[ids[1]:(N-minbuck)]=1.25
  if (length(ids)==2)
  {
    if (N%%2==0)
    {
      calc[ids[1]:(ids[1]+diff(ids)/2-1)]=1
      calc[ids[2]:(ids[2]-diff(ids)/2+1)]=2
      calc[(ids[1]+diff(ids)/2)]=1.25
    }

    if (N%%2==1)
    {
      calc[ids[1]:(ids[1]+diff(ids)/2)]=1
      calc[ids[2]:(ids[2]-diff(ids)/2)]=2
    }
  }

  for (m in which(calc>0 & calc<2))
  {
    mea.t=cc(N,m)
    mea.=mea.t[mea.t>((N+1)/2)]
    spot=ceiling(round(100000000*((mea.-(N+1)/2)/(N-(ceiling(round(minbuck*10000)/10000)-1)/2-(N+1)/2)))/10000)
    tmp=summarize(rep(1,length(spot)),spot,length)
    returned[tmp[,1]]=returned[tmp[,1]]+tmp[,2]/sum(tmp[,2])
    if (calc[m]==1)
    {
      mea.2=(sum(1:N)-mea.t*m)/(N-m)
      mea.=mea.2[mea.2>((N+1)/2)]
      spot=ceiling(round(100000000*((mea.-(N+1)/2)/(N-(ceiling(round(minbuck*10000)/10000)-1)/2-(N+1)/2)))/10000)
      tmp=summarize(rep(1,length(spot)),spot,length)
      returned[tmp[,1]]=returned[tmp[,1]]+tmp[,2]/sum(tmp[,2])
    }
  }
  return(returned/sum(returned))
}
