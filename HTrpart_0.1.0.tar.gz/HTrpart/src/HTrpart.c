#include <Rmath.h>
#include <R.h>
#include <math.h>
#include <stdio.h>

void comb(int *n, int *k, int *out, int *m)
{
  int i, j, use;
  int comb[*k];

  for (i=0; i < *k; i++) comb[i] = i+1;
  for (i=0;i<*k;i++) out[0]+=comb[i];

  for (j=1; j<*m; j++)
  {
    use=0;
    if (comb[*k-1]<*n)
    {
      comb[*k-1]=comb[*k-1]+1;
    }
    else if(comb[*k-1]==*n) {
      for (i=0;i<(*k-1);i++)
      {
        if (comb[i]<*n-*k+i+1) use=i;
      }
      comb[use]=comb[use]+1;
      for (i=(use+1);i<*k;i++) comb[i]=comb[i-1]+1;
    }
    for (i=0;i<*k;i++) out[j]+=comb[i];
 }

}
void CART_cont_2(int *n_ps, int *k, int *N, double *nc, double *output, int *thsd)
{
  int i, j, Start, Stop, Mtemp;
  double MargSum=0, lower, upper, DistSum=0, DistMean, StDev, Divsor, StartZero, StartPlusHalf, Increment;
   double Nd;
  Nd=(double)*N;
  Divsor=.5*(double)(*N-n_ps[0]);
  DistMean=.5*(double)(*N+1);

  for (i=0;i<*k;i++)
  {
    Mtemp=n_ps[i];
    if (Mtemp>3 && Mtemp<(*N-3))
    {
      if (Mtemp*(*N+1) % 2 == 1) Start=(Mtemp*(*N+1)+1)/2;
      if (Mtemp*(*N+1) % 2 == 0) Start=1+Mtemp*(*N+1)/2;
      Stop=Mtemp*((2*(*N))-Mtemp+1)/2;

      StDev=sqrt((double)((*N+1)*(*N-Mtemp))/(double)(12*Mtemp));
      StartZero=(double)(Start)/(double)(Mtemp);
      StartPlusHalf=(double)(Start+.5)/(double)(Mtemp);
      lower=pnorm((double)(Start-.5)/(double)(Mtemp),DistMean+(*nc),StDev,1,0);
      DistSum=pnorm((double)((Stop +.5)/(double)Mtemp),DistMean+(*nc),StDev,1,0)-lower;

      for (j=0;j<Stop-Start+1;j++)
      {
        Increment=(double)j/(double)Mtemp;
        upper=pnorm(StartPlusHalf+Increment,DistMean+(*nc),StDev,1,0);
        output[(int)ceil(round(100000000*(StartZero+Increment-DistMean)/Divsor)/10000)-1]+=(upper-lower)/DistSum;
        lower=upper;
      }
    }
    if (Mtemp<=3 || Mtemp>=(*N-3))
    {
       int i1,j1,use,m,s;
       int comb[Mtemp];
       m=choose(*N,Mtemp);
       double out[m];
       for (i1=0; i1 < m; i1++) out[i1] = 0;
       for (i1=0; i1 < Mtemp; i1++) comb[i1] = i1+1;
       for (i1=0;i1<Mtemp;i1++) out[0]+=(double)comb[i1];

       for (j1=1; j1<m; j1++)
       {
         use=0;
         if (comb[Mtemp-1]<*N)
         {
           comb[Mtemp-1]=comb[Mtemp-1]+1;
         }
         else if(comb[Mtemp-1]==*N) {
           for (i1=0;i1<(Mtemp-1);i1++)
           {
             if (comb[i1]<*N-Mtemp+i1+1) use=i1;
           }
           comb[use]=comb[use]+1;
           for (i1=(use+1);i1<Mtemp;i1++) comb[i1]=comb[i1-1]+1;
         }
         for (i1=0;i1<Mtemp;i1++) out[j1]+=(double)comb[i1];
       }
         for (i1=0;i1<m;i1++) out[i1]=out[i1]/(double)Mtemp;

       s=0;
       for (i1=0;i1<m;i1++) if (out[i1]>(Nd+1)/2) s=s+1;
       for (i1=0;i1<m;i1++)
       {
         if (out[i1]>(Nd+1)/2)
         {
           j1=(int)ceil(round(100000000*((out[i1]-(Nd+1)/2)/(Nd-(ceil(round(n_ps[0]*10000)/10000)-1)/2-(Nd+1)/2)))/10000);
           output[j1-1]+=1/(double)s;
          }
       }
    }
  }
  for (i=0;i<*thsd;i++) MargSum+=output[i];
  for (i=0;i<*thsd;i++) output[i]=output[i]/MargSum;
}



void CART_cont(int *n_ps, int *k, int *N, double *nc, double *output, int *thsd)
{
  int i, j, Start, Stop, Mtemp;
  double MargSum=0,lower, upper, DistSum=0, DistMean, StDev, Divsor, StartZero, StartPlusHalf, Increment;

  Divsor=.5*(double)(*N-n_ps[0]);
  DistMean=.5*(double)(*N+1);

  for (i=0;i<*k;i++)
  {
    Mtemp=n_ps[i];
    if (Mtemp*(*N+1) % 2 == 1) Start=(Mtemp*(*N+1)+1)/2;
    if (Mtemp*(*N+1) % 2 == 0) Start=1+Mtemp*(*N+1)/2;
    Stop=Mtemp*((2*(*N))-Mtemp+1)/2;

    StDev=sqrt((double)((*N+1)*(*N-Mtemp))/(double)(12*Mtemp));
    StartZero=(double)(Start)/(double)(Mtemp);
    StartPlusHalf=(double)(Start+.5)/(double)(Mtemp);
    lower=pnorm((double)(Start-.5)/(double)(Mtemp),DistMean+(*nc),StDev,1,0);
    DistSum=pnorm((double)((Stop +.5)/(double)Mtemp),DistMean+(*nc),StDev,1,0)-lower;

    for (j=0;j<Stop-Start+1;j++)
    {
      Increment=(double)j/(double)Mtemp;
      upper=pnorm(StartPlusHalf+Increment,DistMean+(*nc),StDev,1,0);
      output[(int)ceil(round(100000000*(StartZero+Increment-DistMean)/Divsor)/10000)-1]+=(upper-lower)/DistSum;
      lower=upper;
    }
  }
  for (i=0;i<*thsd;i++) MargSum+=output[i];
  for (i=0;i<*thsd;i++) output[i]=output[i]/MargSum;
/*      Rprintf("%1e\n",MargSum);*/
}



void peeling_cont_resp(int *n_ps, int *k, int *N, double *nc, double *output)
{
  int i, j, count=0, Start, Stop, Mtemp;
  double MargCur=0, MargOld=0, MargSum=0, MargMax=0, lower, upper, DistSum=0, DistMean, StDev, Divsor, StartZero, StartPlusHalf, Increment;
  double MargTemp[*k];
  double Marg[*k];
  for (i=1;i<*N;i++)
  {
    MargCur=log(*N-i+1)+ MargOld-log(i);
   if (i>=n_ps[0])
    {
      if (i<=n_ps[*k-1])
      {
        MargTemp[count]=MargCur;
        count++;
      }
    }
    MargOld=MargCur;
  }

  for (i=0;i<*k;i++) if (MargTemp[i]>MargMax) MargMax=MargTemp[i];

  for (i=0;i<*k;i++)
  {
    Marg[i]=exp(MargTemp[i]-MargMax);
    MargSum+=Marg[i];
  }

  for (i=0;i<*k;i++) Marg[i]=Marg[i]/MargSum;

  Divsor=.5*(double)(*N-n_ps[0]);
  DistMean=.5*(double)(*N+1);

  for (i=0;i<*k;i++)
  {
    Mtemp=n_ps[i];
    if (Mtemp*(*N+1) % 2 == 1) Start=(Mtemp*(*N+1)+1)/2;
    if (Mtemp*(*N+1) % 2 == 0) Start=1+Mtemp*(*N+1)/2;
    Stop=Mtemp*((2*(*N))-Mtemp+1)/2;

    StDev=sqrt((double)((*N+1)*(*N-Mtemp))/(double)(12*Mtemp));
    StartZero=(double)(Start)/(double)(Mtemp);
    StartPlusHalf=(double)(Start+.5)/(double)(Mtemp);
    lower=pnorm((double)(Start-.5)/(double)(Mtemp),DistMean+(*nc),StDev,1,0);
    DistSum=pnorm((double)((Stop +.5)/(double)Mtemp),DistMean+(*nc),StDev,1,0)-lower;

    for (j=0;j<Stop-Start+1;j++)
    {
      Increment=(double)j/(double)Mtemp;
      upper=pnorm(StartPlusHalf+Increment,DistMean+(*nc),StDev,1,0);
      output[(int)ceil(round(100000000*(StartZero+Increment-DistMean)/Divsor)/10000)-1]+=Marg[i]*(upper-lower)/DistSum;
      lower=upper;
    }
  }
}

void peeling(int *n_ps, int *k, int *n1, int *N, double *output)
{
  double out2[*k];
  int out3[*k];
  long int out2sum=0;
  int i,j,p,count=0;

  for (i=0;i<*k;i++)
  {
    out2[i]=0;
    out3[i]=0;
    for (j=1;j<*n1+1;j++) if (j*(*N)>(*n1)*n_ps[i] & j<=n_ps[i]) count++;
    out2[i]=(double)count;
    out2sum+=count;
    count=0;
   }
  double out[out2sum];
  double out1[out2sum];
  double margM[out2sum];

  double actual_sum=0.0;

  for (i=0;i<out2sum;i++) out[i]=out1[i]=margM[i]=0;

  count=0;
  int start=0;
  double denssum=0.0,dens=0.0;

  for (i=0;i<*k;i++)
  {
    out2[i]=0;
    for (j=1;j<*n1+1;j++)
    {
      if (j*(*N)>(*n1)*n_ps[i] & j<=n_ps[i])
      {
        dens=dhyper(j,*n1,(*N)-(*n1),(n_ps[i]),0);
        out[count]=dens;
        out1[count]=(double)j/(double)n_ps[i];
        if (out[count]>0) out3[i]++;
        if (out[count]>0) out2[i]+=dens;
        count++;
      }
    }
    for (p=start;p<count;p++) denssum+=out[p];
    for (p=start;p<count;p++) out[p]=out[p]/denssum;

    start=p;
    count=start;
    denssum=0;
  }

  for (i=0;i<*k;i++) actual_sum+=out2[i];

  count=0;
  for(i=0;i<*k;i++)
  {
    for (j=1;j<out3[i]+1;j++)
    {
      margM[count]=(out2[i])/(actual_sum);
      count++;
    }
  }

  count=0;

  for (i=0;i<out2sum;i++)
  {
    if (out[i]>0)
    {
      output[(int)ceil(round(1000000000*out1[i])/100000)-1]+=(out[i]*margM[count]);
      count++;
    }

  }
}


